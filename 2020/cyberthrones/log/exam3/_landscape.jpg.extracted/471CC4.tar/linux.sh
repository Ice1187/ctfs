#!usr/bin/bash

this is your flag uEXC6fOPQBgJjUL