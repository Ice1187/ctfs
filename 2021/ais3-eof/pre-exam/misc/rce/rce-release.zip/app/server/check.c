#include <stdio.h>

int main() {
    puts("FLAG{example}");
    return 0;
}
