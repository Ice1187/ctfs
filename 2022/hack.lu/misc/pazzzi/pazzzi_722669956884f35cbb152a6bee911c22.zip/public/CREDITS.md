# Civetweb Contributors

* Abhishek Lekshmanan
* Abramo Bagnara
* Adam Bailey
* Adam Hunyadi
* Alan Somers
* Alberto Bignotti
* Alex Kozlov
* Alexander Kozhinov
* AndreyArsov
* Anton Te
* beaver
* bel2125
* Ben M. Ward
* Bernhard Lehner
* BigJoe
* Bjoern Petri
* Braedy Kuzma
* Breno Ramalho Lemes
* brett
* Brian Lambert
* Brian Spratke
* cdbishop
* celeron55
* Charles Olivi
* Chris Han
* Chris Jones
* Chris Rehn
* Christian Mauderer
* Christopher Galas
* cjh
* Colden Cullen
* Colm Sloan
* Cortronic
* Daniel Oaks
* Daniel Rempel
* Danny Al-Gaaf
* Dave Brower
* daveelton
* David Arnold
* David Loffredo
* DavidKorczynski
* Dialga
* dennis
* DL6ER
* Domenico Di Iorio
* dprandle
* Drew Wells
* duong2179
* ehlertjd
* Elan P. Kugelmass
* Eric Tsau
* Erick Vieyra
* Erik Beran
* Erik Partridge
* eugene
* extergnoto
* F-Secure Corporation
* Fabrice Fontaine
* feneuilflo
* Fernando G. Aranda
* Frank Hilliger
* Gábor Csárdi
* gajanak
* Girish Joshi
* goodmenzy
* Grahack
* Gregor Jasny
* grenclave
* grunk
* guangqing.chen
* Guilherme Amadio
* Gustavo Romero
* hansipie
* HariKamath Kamath
* Henry Chang
* Herumb Shandilya
* Herve Codina
* Iain Morton
* ImgBotApp
* Ivan Dlugos
* IZI
* Jack
* Jacob Repp
* Jacob Skillin
* Jan Kowalewski
* Jan Pohanka
* Jan Willem Janssen
* Jens Wallgren
* Jeremy Lin
* Jesse Williamson
* Jim Evans
* jmc-
* Joakim L. Gilje
* Jochen Scheib
* Joe Mucchiello
* Joel Gallant
* Johan De Taeye
* John Faith
* Jordan
* Jordan Shelley
* Joshua Boyd
* Joshua D. Boyd
* Justin Standring
* k-mds
* kakwa
* kalphamon
* Karol Mroz
* Keith Holman
* Keith Kyzivat
* Ken Walters
* Kevin Branigan
* Kevin Wojniak
* Khem Raj
* Kimmo Mustonen
* Kjeld Flarup
* krpano
* Krzysztof Kozlowski
* Lammert Bies
* Lars Immisch
* Lawrence
* Li Peng
* Lianghui
* Lorenzo Canepa
* Luka Rahne
* Lukas Martanovic
* Maarten Fremouw
* makrsmark
* marco
* Mark Lakata
* Martin Gaida
* Mateusz Gralka
* Matt Clarkson
* Mellnik
* Mike Crowe
* mingodad
* Morgan McGuire
* mrdvlpr.xnu
* Nat!
* Neil Jensen
* newsoft
* nfrmtkr
* Nick Hildebrant
* Nigel Stewart
* nihildeb
* No Face Press
* palortoff
* Patrick Drechsler
* Patrick Trinkle
* Paul Sokolovsky
* Paulo Brizolara
* pavel.pimenov
* PavelVozenilek
* Perttu Ahola
* Peter Foerster
* Philipp Friedenberger
* Philipp Hasper
* Pieter Cardoen
* Piotr Zierhoffer
* pkvamme
* Ponnuvel Palaniyappan
* qinch
* qinchao
* r-j-s
* Radoslaw Zarzynski
* Red54
* Retallack Mark mark.retallack
* Richard Screene
* Rimas Misevi-ìius
* Rinat Dobrokhotov
* ryankopf
* Sage Weil
* Sangwhan Moon
* Saumitra Vikram
* Scott Nations
* Sebastien Jodogne
* Sergey Linev
* sgmesservey
* shantanugadgil
* Sherwyn Sen
* shreyajaggi8
* Simon Hailes
* slidertom
* SpaceIm
* SpaceLord
* Stefan Codrescu
* sunfch
* suzukibitman
* Símal Rasmussen
* Tamotsu Kanoh
* thewaterymoon
* Thiago Macedo
* THILMANT, Bernard
* Thomas Davis
* Thomas Klausner
* Thorsten Horstmann
* Tim Gates
* Tim Hudson
* tnoho
* Tom Deblauwe
* Tomas Andrle
* Tomasz Gorochowik
* Toni Wilk
* Torben Jonas
* Uilian Ries
* Ulrich Hertlein
* Walt Steverson
* wangli28
* webxer
* William Greathouse
* Wolfram Rösler
* xeoshow
* xtne6f
* Yehuda Sadeh
* Yury Z
* zhen.wang

and others.

# Mongoose Contributors
CivetWeb is based on the Mongoose code.  The following users contributed to the original Mongoose release between 2010 and 2013.  This list was generated from the Mongoose GIT logs.  It does not contain contributions from the Mongoose mailing list.  There is no record for contributors prior to 2010.

* Sergey Lyubka
* Arnout Vandecappelle (Essensium/Mind)
* Benoît Amiaux
* Cody Hanson
* Colin Leitner
* Daniel Oaks
* Eric Bakan
* Erik Oomen
* Filipp Kovalev
* Ger Hobbelt
* Hendrik Polczynski
* Henrique Mendonça
* Igor Okulist
* Jay
* Joe Mucchiello
* John Safranek
* Joseph Mainwaring
* José Miguel Gonçalves
* KIU Shueng Chuan
* Katerina Blinova
* Konstantin Sorokin
* Marin Atanasov Nikolov
* Matt Healy
* Miguel Morales
* Mikhail Nikalyukin
* MikieMorales
* Mitch Hendrickson
* Nigel Stewart
* Pavel
* Pavel Khlebovich
* Rogerz Zhang
* Sebastian Reinhard
* Stefan Doehla
* Thileepan
* abadc0de
* arvidn
* bick
* ff.feng
* jmucchiello
* jwang
* lsm
* migal
* mlamb
* nullable.type
* shantanugadgil
* tayS
* test
* valenok
