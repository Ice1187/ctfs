[TOC]

# Civetweb websocket cpp

## #1 Installation

```shell
git clone https://github.com/civetweb/civetweb.git
mkdir buildx && cd buildx
cmake -DBUILD_SHARED_LIBS=ON -DCIVETWEB_ENABLE_WEBSOCKETS=ON -DCIVETWEB_ENABLE_CXX=ON ..
make
sudo make install
```




