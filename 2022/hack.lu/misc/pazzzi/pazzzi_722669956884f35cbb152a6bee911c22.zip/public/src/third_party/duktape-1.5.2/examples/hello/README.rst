===================
Hello world example
===================

Very simple example, most useful for compilation tests.
