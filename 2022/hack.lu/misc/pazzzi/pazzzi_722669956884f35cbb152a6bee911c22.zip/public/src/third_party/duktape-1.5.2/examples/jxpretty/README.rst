================
Jxpretty example
================

Simple command line utility to pretty print JSON in the JX format.
