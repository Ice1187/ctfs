
function onload() {
	document.getElementById("div1").innerHTML = "script started";
}
