<html>
  <form method="post">
    <input name="x" type="text" />
    <input type="submit" />
  </form>

  <? echo $_POST["x"]; ?>
  
</html>
